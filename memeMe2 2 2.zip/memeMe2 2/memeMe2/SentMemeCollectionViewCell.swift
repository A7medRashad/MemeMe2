//
//  SentMemeCollectionViewCell.swift
//  memeMe2
//
//  Created by Ahmed Rashad AbdElGhany Haridy on 19/03/2022.
//

import UIKit

class SentMemeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var cellImageView: UIImageView!
    
}
