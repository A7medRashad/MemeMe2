//
//  CollectionViewController.swift
//  memeMe2
//
//  Created by Ahmed Rashad AbdElGhany Haridy on 19/03/2022.
//


import UIKit


class CollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {

    // MARK: - Properties: Non-Outlets
    
    let reusableCollectionCellIdentifier = "reusableCollectionCell"
    
    // indicates whether this controller initiated a segue -
    //  used to determine whether this controller can respond to an unwind request
    var startedEditorSegue = false
    var startedDetailSegue = false
    
    
    @IBOutlet var flowLayout: UICollectionViewFlowLayout!
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    // MARK: - Collection View Controller Overrides
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Register cell classes - not needed because "registered" within storyboard
        // self.collectionView!.registerClass(UICollectionViewCell.self, forCellWithReuseIdentifier: reusableCollectionCellIdentifier)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        collectionView?.reloadData()
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if collectionView != nil {
            collectionView?.reloadData()
        }
    }
    // To correctly use flow layout and show the images evenly across the collection view
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {

        let space:CGFloat = 3.0
        let dimension = (view.frame.size.width - (2 * space)) / 3.0
        return CGSize(width: dimension, height: dimension)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 3
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 3
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {

      if collectionView.numberOfItems(inSection: section) == 1 {

           let flowLayout = collectionViewLayout as! UICollectionViewFlowLayout

          return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: collectionView.frame.width - flowLayout.itemSize.width)

      }

      return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)

  }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let numMemes = MemeData.allMemes.count
        let isEmpty = (numMemes == 0)
        
        setUpCollectionViewBackground(isEmpty)
        
        // reload collection to ensure all memes are displayed
        collectionView!.reloadData()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let segueId = segue.identifier else {
            return
        }
        
        switch segueId {
            
        case "collectionViewSegueToDetail":
            let sendingCell = sender as! UICollectionViewCell
            let sendingCellIndexPath = collectionView!.indexPath(for: sendingCell)!
            let selectedMeme = sendingCellIndexPath.row
            
            let controller = segue.destination as! DetailViewController
            controller.selectedMeme = MemeData.allMemes[selectedMeme]
            
            startedDetailSegue = true
            
        case "collectionViewSegueToEditor":
            startedEditorSegue = true
            
        default:
            print("unknown segue: \(segueId)")
        }
    }
    
    override func canPerformUnwindSegueAction(_ action: Selector, from fromViewController: UIViewController, withSender sender: Any) -> Bool {
        
        // if we started the segue, then we can handle it; otherwise, pass
        switch action {
            
        case #selector(CollectionViewController.unwindFromEditor(_:)):
            let isUnwindResponder = startedDetailSegue || startedEditorSegue
            
            return isUnwindResponder
            
        default:
            return false
        }
    }
    
    override func willRotate(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        
        // redraw on rotation so resizes cells properly
        collectionView!.reloadData()
    }
    
    
    // MARK: - Actions
    
    @IBAction func unwindFromEditor(_ segue: UIStoryboardSegue) {
        
        // the editor's unwind came here; all we need do is revert the indicator
        //    to false, so it's valid for the next unwind action
        startedEditorSegue = false
        startedDetailSegue = false
    }
    
    
    // MARK: - Collection View Data Source

    // using default number of sections (1), so no override for numberOfSections
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        let numItems = MemeData.allMemes.count
        
        return numItems
        
        
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reusableCollectionCellIdentifier, for: indexPath) as! SentMemeCollectionViewCell
        
        let cellImageView = cell.viewWithTag(1) as! UIImageView
        
        cellImageView.image = MemeData.allMemes[indexPath.row].memeImage

        return cell
    }

    
    // MARK: - Utility Functions
    
    func setUpCollectionViewBackground(_ isEmpty: Bool) {
        
        guard let theCollectionView = collectionView else {
            return
        }
        
        // code modified from:
        // iOS Programming 101: Implementing Pull-to-Refresh and Handling Empty Table
        //    Simon Ng, 11 July 2014
        //    http://www.appcoda.com/pull-to-refresh-uitableview-empty/
        
        let emptyMessageText = "No Memes Share it."
        let fontName = "Palatino-Italic"
        let fontSize: CGFloat = 20.0
        
        if !isEmpty {
            if theCollectionView.backgroundView != nil {
                theCollectionView.backgroundView = nil
            }
        }
        else {
            if theCollectionView.backgroundView == nil {
                let emptyMessageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: view.bounds.size.width, height: view.bounds.size.height))
                emptyMessageLabel.text = emptyMessageText
                emptyMessageLabel.numberOfLines = 0
                emptyMessageLabel.font = UIFont(name: fontName, size: fontSize)
                emptyMessageLabel.textAlignment = .center
                emptyMessageLabel.sizeToFit()
                
                theCollectionView.backgroundView = emptyMessageLabel
            }
        }
    }
    
}
