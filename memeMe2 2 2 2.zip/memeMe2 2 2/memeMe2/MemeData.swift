//
//  MemeData.swift
//  memeMe2
//
//  Created by Ahmed Rashad AbdElGhany Haridy on 19/03/2022.
//

import Foundation

struct MemeData {
    
    // MARK: - Properties: Type ("Class" in other languages)
    
    static var allMemes = [Meme]()
    
}
